import subprocess
import re
import os
import sys
import json

def secretVaild():
# 检查是否存在ceph的secret
    list_process = subprocess.Popen(["virsh", "secret-list"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    list_output, list_error = list_process.communicate()

    uuid = None  # 设置默认值
    
    if b"ceph client.admin secret" in list_output:
        lines = list_output.decode("utf-8").splitlines()
        for line in lines:
            if "ceph client.admin secret" in line:
                uuid = line.split()[0]
                break
    else:
        define_process = subprocess.Popen(["virsh", "secret-define", "secret.xml"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        define_output, define_error = define_process.communicate()
        if b"created" in define_output:
            uuid = define_output.decode("utf-8").split()[-2]
    # print(uuid)

    get_value_process = subprocess.Popen(["virsh", "secret-get-value", "--secret", uuid], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    get_value_output, get_value_error = get_value_process.communicate()
    if b"Secret not found" in get_value_error:
        with open("/etc/ceph/client.admin.keyring", "r") as keyring_file:
            keyring_contents = keyring_file.read()
            key_start = keyring_contents.find("key = ") + len("key = ")
            key_end = keyring_contents.find("\n", key_start)
            key = keyring_contents[key_start:key_end].strip()
            # print(key)

        set_value_process = subprocess.Popen(["virsh", "secret-set-value", "--secret", uuid, "--base64", key], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        set_value_output, set_value_error = set_value_process.communicate()
        # print(set_value_output.decode("utf-8"))
        
    return uuid


def getCephIp():
    # 读取ceph.conf文件内容
    with open('/etc/ceph/ceph.conf', 'r') as conf_file:
        conf_content = conf_file.read()
        
    # 使用正则表达式提取v1的信息
    pattern = r"v1:(\d+\.\d+\.\d+\.\d+):(\d+)"
    matches = re.findall(pattern, conf_content)
    ip_address = []
    for match in matches:
        ip_address.append(match[0])
        port = match[1]
        
    return ip_address, port
    
def addDisk(image, uuId, dev, ips, port, xmlFile):
    os.system("cp virDisk.xml test.xml")
    cmd = f"sed -i \"s/<host name='[^']*' port='[^']*'/<host name='{ips[0]}' port='{port}'/g\" test.xml"
    os.system(cmd)
    for ip in ips[1:]:
        cmd = f"sed -i \"/<\/source>/i \ \ \ \ \ \ \ \ \ <host name='{ip}' port='{port}'\/>\" test.xml"
        os.system(cmd)
    cmd = f"sed -i \"s/uuid='uuid'/uuid='{uuId}'/g\" test.xml"
    os.system(cmd)
    cmd = f"sed -i \"s/dev='vdb'/dev='{dev}'/g\" test.xml"
    os.system(cmd)
    cmd = f"sed -i \"s#name='test/test.img'#name='{image}'#g\" test.xml"
    os.system(cmd)
    
    cmd = f"sed -i '/<devices>/r test.xml' {xmlFile}"
    os.system(cmd)
    
    os.system("rm -f test.xml")

if __name__ == "__main__":
    id = secretVaild()
    ips, port = getCephIp()
    ips = ['172.28.141.161', '172.28.141.145']
    images = []
    images = json.loads(sys.argv[1])
    print(ips)
    index = 'a'
    for image in images:
        print(image)
        index = chr(ord(index) + 1)
        dev = "vd" + index
        addDisk(image, id, dev, ips, port, "")
    