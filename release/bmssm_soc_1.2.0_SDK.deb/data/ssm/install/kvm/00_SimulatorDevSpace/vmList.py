#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
import sys
import logging
import json


def vm_list(vmName):
    response = {"code":0,"msg":""}
    fp = os.popen("virsh list --all")
    checkVm = fp.read().split("\n")
    # logging.info(len(checkVm))
    fp.close()
    if(checkVm):
        if(len(checkVm) > 4):
            for i in range(2,len(checkVm)):
                if(checkVm[i] != ''):
                    kvmname = checkVm[i].split()
                    logging.info("%s,kvmname:%s"%(i,kvmname))
                    if(kvmname[1] == vmName):
                        if(kvmname[2] == 'running'):
                            response["code"] = 0
                            response["msg"] = "Domain %s status is running"%vmName
                            logging.info(response)  
                            break
                        elif(kvmname[2] == 'shut'):
                            response["code"] = 0
                            response["msg"] = "Domain %s status is shutdown"%vmName
                            logging.info(response)
                            break                 
                    elif(i == (len(checkVm)-3)):
                        response["code"] = 1
                        response["msg"] = "Domain {} not existed".format(vmName)
                        logging.info(response)
                        break                 
        else:
            response["code"] = 1
            response["msg"] = "no one Domain "
            logging.info(response)  
    print(json.dumps(response))
    return(response)    

if __name__ == '__main__':
    response = {"code":1,"msg":""}
    os.popen("mkdir -p logs")
    logging.basicConfig(filename='logs/'+'list.log',format='%(asctime)s %(levelname)s %(message)s',\
        datefmt='%Y-%m-%d %H:%M:%S',level=logging.INFO)
    logging.info('\r')
    logging.info("----------------start-----------------------------")
    logging.info("外部vmList.py调用记录：sys.argv:{}".format(sys.argv))
    if(len(sys.argv) <= 1):
        response["code"] = 1
        response["msg"] = "argv ERR"
        logging.info("调用vm_list方法查询结果：{}".format(response))
        print(json.dumps(response))
        sys.exit(1)
    vmName = sys.argv[1]
    vm_list(vmName)
    logging.info("----------------end-------------------------------")