import subprocess
import re
import os
import sys
import json
import xml.etree.ElementTree as ET
import libvirt
import json
import os
import sys
import logging

def secretVaild():
# 检查是否存在ceph的secret
    list_process = subprocess.Popen(["virsh", "secret-list"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    list_output, list_error = list_process.communicate()

    uuid = None  # 设置默认值
    
    if b"ceph client.admin secret" in list_output:
        lines = list_output.decode("utf-8").splitlines()
        for line in lines:
            if "ceph client.admin secret" in line:
                uuid = line.split()[0]
                break
    else:
        define_process = subprocess.Popen(["virsh", "secret-define", "secret.xml"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        define_output, define_error = define_process.communicate()
        if b"created" in define_output:
            uuid = define_output.decode("utf-8").split()[-2]
    # print(uuid)

    get_value_process = subprocess.Popen(["virsh", "secret-get-value", "--secret", uuid], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    get_value_output, get_value_error = get_value_process.communicate()
    if b"Secret not found" in get_value_error:
        with open("/etc/ceph/client.admin.keyring", "r") as keyring_file:
            keyring_contents = keyring_file.read()
            key_start = keyring_contents.find("key = ") + len("key = ")
            key_end = keyring_contents.find("\n", key_start)
            key = keyring_contents[key_start:key_end].strip()
            # print(key)

        set_value_process = subprocess.Popen(["virsh", "secret-set-value", "--secret", uuid, "--base64", key], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        set_value_output, set_value_error = set_value_process.communicate()
        # print(set_value_output.decode("utf-8"))
        
    return uuid


def getCephIp():
    # 读取ceph.conf文件内容
    with open('/etc/ceph/ceph.conf', 'r') as conf_file:
        conf_content = conf_file.read()
        
    # 使用正则表达式提取v1的信息
    pattern = r"v1:(\d+\.\d+\.\d+\.\d+):(\d+)"
    matches = re.findall(pattern, conf_content)
    ip_address = []
    for match in matches:
        ip_address.append(match[0])
        port = match[1]
        
    return ip_address, port
    
    
def xmlDisk(image, uuId, dev, ips, port):
    os.system("cp virDisk.xml test.xml")
    cmd = f"sed -i \"s/<host name='[^']*' port='[^']*'/<host name='{ips[0]}' port='{port}'/g\" test.xml"
    os.system(cmd)
    for ip in ips[1:]:
        cmd = f"sed -i \"/<\/source>/i \ \ \ \ \ \ \ \ \ <host name='{ip}' port='{port}'\/>\" test.xml"
        os.system(cmd)
    cmd = f"sed -i \"s/uuid='uuid'/uuid='{uuId}'/g\" test.xml"
    os.system(cmd)
    cmd = f"sed -i \"s/dev='vdb'/dev='{dev}'/g\" test.xml"
    os.system(cmd)
    cmd = f"sed -i \"s#name='test/test.img'#name='{image}'#g\" test.xml"
    os.system(cmd)


def getAllDev(vmName):
    conn = libvirt.open('qemu:///system')
    vm = conn.lookupByName(vmName)
    
    # 获取虚拟机当前的 XML 配置
    vmXml = vm.XMLDesc()
    tree = ET.ElementTree(ET.fromstring(vmXml))
    root = tree.getroot()
    
    # 查找所有匹配条件的 <target> 元素的 dev 属性值
    targetElements = root.findall(".//disk[@type='network']/target")
    devValues = [target.get("dev") for target in targetElements if target.get("dev")]
    
    conn.close()
    # 按名称排序 dev 属性值
    res = sorted(devValues)
    return res
    # last_dev_value = sorted_dev_values[-1]

def getDev(vmName, image):
    cmd = f"virsh domblklist {vmName}"
    output = os.popen(cmd).read()

    lines = output.splitlines()

    dev = ""
    lines = output.splitlines()
    for line in lines:
        if image in line:
            dev = line.split()[0]
            break
    return dev

def deleteCephDisk(vmName, targetDevs):
    response = {"code":0,"msg":""}
    conn = libvirt.open('qemu:///system')
    
    try:
        vm = conn.lookupByName(vmName)
        if vm is None:
            raise Exception(f"VM '{vmName}' not found.")
        
        # 获取虚拟机当前的 XML 配置
        vmXml = vm.XMLDesc()
        
        # 从虚拟机的 XML 中移除目标设备名称为 targetDev 的磁盘配置
        # 解析虚拟机的XML配置
        tree = ET.ElementTree(ET.fromstring(vmXml))
        root = tree.getroot()
        
        for targetDev in targetDevs:
            for diskElem in root.findall(".//disk[@type='network']"):
                print(diskElem)
                target_elem = diskElem.find("target")
                if target_elem is not None and target_elem.get("dev") == targetDev:
                    root.find("devices").remove(diskElem)
                    print(f"Disk '{targetDev}' removed from VM.")
                    break
        
        updated_vmXml = ET.tostring(root, encoding="utf-8").decode("utf-8")
        
        # 更新虚拟机的 XML 配置
        new_vm = conn.defineXML(updated_vmXml)
        print(new_vm)
        
        response["msg"] = f"{vmName} delete {targetDevs} success"
        print(json.dumps(response))
        logging.info(response)  
        
    except Exception as e:
        response["code"] = 1
        response["msg"] = f"Error: {e}"
        print(json.dumps(response))
        logging.info(response)  
    finally:
        conn.close()

def addDiskXml(vmName, cephXmls):
    response = {"code":0,"msg":""}
    conn = libvirt.open('qemu:///system')
    
    try:
        vm = conn.lookupByName(vmName)
        if vm is None:
            raise Exception(f"VM '{vmName}' not found.")
        
        # 获取虚拟机当前的 XML 配置
        vmXml = vm.XMLDesc()
        
        # 从虚拟机的 XML 中移除目标设备名称为 targetDev 的磁盘配置
        # 解析虚拟机的XML配置
        tree = ET.ElementTree(ET.fromstring(vmXml))
        root = tree.getroot()
        
        for xml in cephXmls:
            root.find("devices").append(xml)
        
        updated_vmXml = ET.tostring(root, encoding="utf-8").decode("utf-8")
        
        # 更新虚拟机的 XML 配置
        new_vm = conn.defineXML(updated_vmXml)
        # print(new_vm)
        
        response["msg"] = f"{vmName} add ceph disk success"
        print(json.dumps(response))
        logging.info(response)  
    except Exception as e:
        response["code"] = 1
        response["msg"] = f"Error: {e}"
        print(json.dumps(response))
        logging.info(response)  
    finally:
        conn.close()

def isVmExist(vmName):
    cmd = "virsh list --all"
    output = os.popen(cmd).read()

    return vmName in output

def isImageInVm(vmName, image):
    cmd = f"virsh domblklist {vmName}"
    output = os.popen(cmd).read()

    return image in output

# shut off -- False
# running -- True
def getVmStatus(vmName):
    cmd = f"virsh domstate {vmName}"
    status = os.popen(cmd).read().strip()
    return status != "shut off"