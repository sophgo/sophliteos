#!/usr/bin/python
from hashlib import md5
import os
import sys
import time
import logging
import json
import vmList
import ceph

def VirtualCreate(vmName,ip,loginName="sophgo",password='',cpuCore=2,memory=4,disk=2,chips=[],cephImages=[]):
    vmName = sys.argv[1]
    ip = sys.argv[2]
    loginName = sys.argv[3]
    password = sys.argv[4]
    cpuCore =  sys.argv[5]
    memory = sys.argv[6]
    disk = sys.argv[7]
    chips = sys.argv[8]
    cephImages = sys.argv[9]
    
    logging.info("VirtualCreate:%s,%s,%s,%s,%s,%s,%s,%s,%s"\
        %(vmName,ip,loginName,password,cpuCore,memory,disk,chips,cephImages))
    
    dic_kvm = vmList.vm_list(vmName)
    logging.info("dic_kvm:%s"%dic_kvm)
    if(dic_kvm["code"] == 0):
        response["code"] = 1
        response["msg"] = " Domain %s already exists,cat not create "%vmName
        logging.info(" Domain %s already exists,cat not create "%vmName)
        print(json.dumps(response))
        logging.info(response)
        sys.exit(1)
    #创建网桥,人工预置
    # os.popen("sudo sed -i \"$a\$r50-cloud-init.yaml\"  /etc/netplan/50-cloud-init.yaml")
    # os.popen("sudo netplan apply")

    images = json.loads(cephImages)
    if (len(images) > 0):
        uuid = ceph.secretVaild()
        cephIp, cephPort = ceph.getCephIp()
        if (len(cephIp) == 0 or cephPort == ""):
            logging.info(" cephIp or cephPort error ")
            sys.exit(1)
        index = 'a'
        for image in images:
            index = chr(ord(index) + 1)
            cephDev = "vd" + index
            ceph.addDisk(image, uuid, cephDev, cephIp, cephPort, "CmodelVirtualDomain.xml")
            
    #内存memory
    GBYTE = 1048576
    memory = int(memory) * GBYTE
    os.system("sed -i \"s/<memory>.*<\/memory>/<memory>%s<\/memory>/g\" CmodelVirtualDomain.xml"%(memory))
    time.sleep(1)
    os.system("sed -i \"s/<currentMemory>.*<\/currentMemory>/<currentMemory>%s<\/currentMemory>/g\" CmodelVirtualDomain.xml"%(memory))
    time.sleep(1)
    #cpu内核
    os.system("sed -i \"s/<vcpu>.*<\/vcpu>/<vcpu>%s<\/vcpu>/g\" CmodelVirtualDomain.xml"%cpuCore)
    time.sleep(1)
    #vmName
    os.system("sed -i \"s/<name>.*<\/name>/<name>%s<\/name>/g\" CmodelVirtualDomain.xml"%vmName)
    time.sleep(1)

    fp = os.popen("cat CmodelVirtualDomain.xml")
    xml_content = fp.read()
    logging.info("kvm xml content:'\n' %s"%xml_content)
    fp.close()

    #disk create,先注释掉，竞赛版本不用
    # disk_create = os.popen("qemu-img create -f qcow2 ExpansionDisk.qcow2 %sG"%(disk)).read()
    # if(disk_create[0:10] == "Formatting"):
    #     response["code"] = 0
    #     response["msg"] = "成功"
    # else:
    #     response["code"] = 1
    #     response["msg"] = "磁盘空间失败,%s"%(disk_create)
    # os.popen("sed -i \"s/\/mnt\/test\/ExpansionDisk.qcow2/\/mnt\/%s\/ExpansionDisk.qcow2/g\" CmodelVirtualDomain.xml"%vmName)
    
    
    #创建虚拟机，并开启这个虚拟机
    # md5_qcow2 = os.popen("date -R && md5sum kvm-release-v1.0.qcow2 && date -R ").read()
    # logging.info("{}".format(md5_qcow2))
    os.system("virsh define CmodelVirtualDomain.xml")
    time.sleep(5)
    # os.popen("virsh shutdown %s"%vmName).read()

    #修改静态ip,需要关机状态下操作
    #sudo virt-edit -d test /etc/netplan/50-cloud-init.yaml  -e "s/true/false/" 
    #sudo virt-edit -d test /etc/netplan/50-cloud-init.yaml -e "s/-\ .*\/24/-\ 172.28.141.56\/24/"

    step1 = os.popen("virsh list --all |grep %s"%vmName).read().split("\n")
    logging.info("---step1---，define后，应当是shut off；实际结果是：{}".format(step1))

    os.system("sudo virt-edit -d %s /etc/netplan/50-cloud-init.yaml -e \"s#true#false#\""%vmName)
    time.sleep(5)
    os.system("sudo virt-edit -d %s /etc/netplan/50-cloud-init.yaml -e \"s#-\ .*\/24#-\ %s\/24#\""%(vmName,ip))
    # os.popen("sudo virt-edit -d vm-01 /etc/netplan/50-cloud-init.yaml -e \"s#-\ .*\/24#-\ 172.28.8.51\/24#\"")
    time.sleep(5)

    step2 = os.popen("virsh list --all |grep %s"%vmName).read().split("\n")
    logging.info("---step2---，修改ip后，应当是shut off；实际结果是：{}".format(step2))
    
    # 修改虚机密码，前提是虚拟机是runnning的状态才能操作，参考如下命令
    # virsh set-user-password test-clone-new sophgo sophgo123
    start_status = os.popen("virsh start %s"%vmName).read()
    logging.info("start_status:%s"%start_status)
    #Domain kvm-2022-01-19 started
    if(start_status[0:6] != "Domain"):
        logging.info("启动虚机%s报错，检查芯片是否占用，或者磁盘镜像"%vmName)
        response["code"] = 1
        response["msg"] = "Domain %s start err，please check chips occupy，or check disk"%vmName
        print(json.dumps(response))
        logging.info(response)
        sys.exit(1)
    time.sleep(50)

    back_ping = os.system('ping -c 1 -w 1 %s'%ip)
    if(back_ping):
        response["code"] = 1
        response["msg"] = "change ip %s err，"%ip
        print(json.dumps(response))
        logging.info(response)
        sys.exit(1)
    else:
        logging.info("---step3 虚机ip修改---,")
        logging.info("virtual ip set successfully for %s"%vmName)

    fp = os.popen("virsh set-user-password %s %s %s"%(vmName,loginName,password))
    re_passwd = fp.read()
    fp.close()
    #新加内容
    if(re_passwd.find('successfully') == -1):
        response["code"] = 1
        response["msg"] = 'set-user-password failed'
        print(json.dumps(response))
        logging.info(response)
        sys.exit(1)
    else:
        logging.info(re_passwd)

    logging.info("结束程序前返回给调用者再次查询")
    check_kvm = vmList.vm_list(vmName)
    logging.info("check_kvm:%s"%check_kvm)
    if((check_kvm["code"] == 0) and (check_kvm["msg"] == "Domain %s status is running"%vmName)):
        response["code"] = 0
        response["msg"] = "Domain %s status is running, create successful"%vmName
        logging.info(response)
        print(json.dumps(response))
    elif( (check_kvm["code"] == 0) and (check_kvm["msg" == "Domain %s status is shutdown"%vmName]) ):
        response["code"] = 1
        response["msg"] = "Domain %s status is shutdown，create failed"%vmName
        logging.info(response)
        print(json.dumps(response))
    else:
        response["code"] = 1
        response["msg"] = "Domain %s not found:create failed"%vmName
        logging.info('\r')
        logging.info(response)
        print(json.dumps(response))

    
if __name__ == "__main__":
    response = {"code":0,"msg":""}
    os.system("mkdir -p logs")
    logging.basicConfig(filename='logs/'+'create.log',format='%(asctime)s %(levelname)s %(message)s',datefmt='%Y-%m-%d %H:%M:%S',level=logging.INFO)

    logging.info('\r')
    logging.info("----------------start-----------------------------")
    logging.info("CreateKvmCmodel.py调用记录：sys.argv:{}".format(sys.argv))
    logging.info("%s"%sys.argv)
    if(len(sys.argv) != 10):
        response["code"] = 1
        response["msg"] = "传参不对"
        logging.info(response)  
        sys.exit(1)

    #不通虚拟机的xml，放在不同的目录
    pydir = os.getcwd()
    os.system("mkdir -p /mnt/%s"%sys.argv[1])
    time.sleep(1)
    os.system("\cp CmodelVirtualDomain.xml secret.xml virDisk.xml /mnt/%s"%sys.argv[1])
    #镜像名字待定，暂时kvm-cmodel.qcow2
    fp = os.popen("date -R")
    start_cp = fp.read()
    fp.close()
    logging.info("开始拷贝镜像，:%s"%start_cp)
    os.system("\cp /data/qemu-img/kvm-cmodel.qcow2 /mnt/%s"%sys.argv[1])
    # time.sleep(420)
    #time.sleep(420) 竞赛现场机器HDD再进行调整
    fp = os.popen("date -R")
    end_cp = fp.read()
    fp.close
    logging.info("结束拷贝镜像，：%s"%end_cp)

    os.chdir("/mnt/%s"%sys.argv[1])
    os.popen("sed -i \"s/ubuntu-img/%s/g\" CmodelVirtualDomain.xml"%(sys.argv[1]))
    
    '''
        python3 CreateKvmCmodel.py "vm-01" "172.28.8.50" "sophgo" 'sophgo123' '4' '16' '32'\
            '[["05:00.0","05:00.1","05:00.2"]]' '["ceph-demo/test.img","ceph-demo/test1.img"]'

    '''

    re1 = VirtualCreate(sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4],sys.argv[5],sys.argv[6],sys.argv[7],sys.argv[8],sys.argv[9])
    # print(re1)

    os.chdir(pydir)
    # print(os.getcwd())
    logging.info("----------------end-------------------------------")
