#!/bin/bash
 
if [ $# -lt 1   ] ; then
    echo "eg: bm_set_ip_auto eth0"
    exit -1
fi
 
 
device=$1
 
 
is_ubuntu=$(cat /etc/os-release | grep Ubuntu |wc -l)
 
 
if [ $is_ubuntu -gt 1 ];then
        echo "ubuntu"
        device_path="/etc/netplan/01-network-manager-all.yaml"
        #device_path="/etc/netplan/01-netcfg.yaml"
        #device_path="01-netcfg.yaml"
        if [ ! -f "$device_path" ]; then
                device_path="/etc/netplan/01-netcfg.yaml"
        fi
        eth_num=$(grep -inr "$device:" $device_path | awk -F : '{print $1}')
        num=$(($eth_num+5))
        if [ ! $eth_num = "" ];then
                for ((i=1; i<=8; i++))
                do
                        num=$(($eth_num+$i))
                        c_str=$(sed -n "${num}p" $device_path | awk -F : '{print$1}')
                        echo $c_str
                        if [[ $c_str =~ "-" ]]||[[ $c_str =~ "dhcp" ]] || [[ $c_str =~ "addresses" ]] || [[ $c_str =~ "gateway4" ]] || [[ $c_str =~ "nameservers" ]] || [[ $c_str =~ "optional" ]];then
                                d_str="${num}d"
                        else
                                break;
                        fi
                done
                echo "$eth_num,$d_str"
                sudo sed -i "$eth_num,$d_str" $device_path
                sudo sync
        fi
        echo "add network config"
        echo "                ${device}:" | sudo tee -a $device_path
        echo "                        dhcp4: yes" | sudo tee -a  $device_path
        echo "                        addresses: []" | sudo tee -a  $device_path
        echo "                        dhcp-identifier: mac" | sudo tee -a  $device_path
        echo "                        optional: yes" | sudo tee -a  $device_path
        sudo sync
        sudo netplan apply
 
 
else
        echo "debian"
        sudo rm -rf /etc/network/interfaces.d/$device
        sync
        sudo ip addr flush dev eth0
        sudo service networking restart
        sudo systemctl restart NetworkManager
fi