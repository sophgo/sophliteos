#!/bin/sh

CONF_PATH="/etc/ssm/conf"

SHELL_FOLDER=$(dirname $(readlink -f "$0"))
echo $SHELL_FOLDER


systemctl stop bmssm.service

cp $SHELL_FOLDER/bmssmVersion.txt $CONF_PATH
cp $SHELL_FOLDER/*.sh $CONF_PATH
cp $SHELL_FOLDER/*.exp $CONF_PATH
cp $SHELL_FOLDER/vmConf.json $CONF_PATH
cp $SHELL_FOLDER/bmssm /bin
cp $SHELL_FOLDER/*.so*   $CONF_PATH
cp -r $SHELL_FOLDER/kvm $CONF_PATH

LIB_FILE="/opt/sophon/libsophon-current/lib/libbmlib.so.0"
DEST_FILE="${CONF_PATH}/libbmlib.so.0"
LINK_NAME="${CONF_PATH}/libmlib.so"

if [ -f "$LIB_FILE" ]; then
    cp "$LIB_FILE" "$CONF_PATH"

    if [ -e "$LINK_NAME" ]; then
        rm "$LINK_NAME"
    fi

    ln -s "$DEST_FILE" "$LINK_NAME"
fi
systemctl start bmssm.service
