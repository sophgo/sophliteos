#!/bin/sh

CONF_PATH="/etc/ssm/conf"

SHELL_FOLDER=$(dirname $(readlink -f "$0"))
echo $SHELL_FOLDER


systemctl stop bmssm.service

cp $SHELL_FOLDER/bmssmVersion.txt $CONF_PATH
cp $SHELL_FOLDER/*.sh $CONF_PATH
cp $SHELL_FOLDER/*.exp $CONF_PATH
cp $SHELL_FOLDER/vmConf.json $CONF_PATH
cp $SHELL_FOLDER/bmssm /bin
cp $SHELL_FOLDER/*.so*   $CONF_PATH
cp -r $SHELL_FOLDER/kvm $CONF_PATH

systemctl start bmssm.service
