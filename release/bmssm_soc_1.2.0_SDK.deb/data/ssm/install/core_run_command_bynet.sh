#!/bin/bash



if [ $# -lt 3  ] ; then
    echo "-------------------------------------------------------------------- "
    echo "this script used by run command for all cores or one core"
    echo "run for all cores"
    echo "      eg: ./core_run_command_bynet.sh /bm_bin/bm_version linaro linaro"
    echo "-------------------------------------------------------------------- "
    echo "run for one core"
    echo "      eg: ./core_run_command_bynet.sh /bm_bin/bm_version linaro linaro 5"

    exit -1
fi

pushd /etc/ssm/conf

echo "do $4"

./ssh_anycmd.exp "$4" $2 $3 "$1"

echo "run command finish"

popd
echo "run all command finish"
