#!/bin/sh

CONF_PATH="/etc/ssm/conf"
DB_PATH="/var/ssm/dbdata"
BACKUP_CONF="/data/ssm/conf/deviceConf.json"

SHELL_FOLDER=$(dirname $(readlink -f "$0"))
echo $SHELL_FOLDER

### 
### 1. Copy config file
### if you wantto disable auth, change this file
###
if [ ! -d $CONF_PATH ]; then
    mkdir -p $CONF_PATH
fi

cp $SHELL_FOLDER/*.yaml $CONF_PATH
cp $SHELL_FOLDER/*.json $CONF_PATH
cp $SHELL_FOLDER/*.sh   $CONF_PATH
cp $SHELL_FOLDER/*.exp  $CONF_PATH
cp $SHELL_FOLDER/*.so*   $CONF_PATH
cp $SHELL_FOLDER/bmssmVersion.txt $CONF_PATH

if [ -f $BACKUP_CONF ]; then
    cp $BACKUP_CONF $CONF_PATH
    rm -f $BACKUP_CONF
fi

LIB_FILE="/opt/sophon/libsophon-current/lib/libbmlib.so.0"
DEST_FILE="${CONF_PATH}/libbmlib.so.0"
LINK_NAME="${CONF_PATH}/libmlib.so"

rm /etc/ssm/conf/libbmlib.so
rm /etc/ssm/conf/libbmlib.so.0

ln -s /opt/sophon/libsophon-current/lib/libbmlib.so.0  /etc/ssm/conf/libbmlib.so
ln -s /opt/sophon/libsophon-current/lib/libbmlib.so.0  /etc/ssm/conf/libbmlib.so.0

###
### 2. Copy db ; if file has been there ,we won't change it any more
###
if [ ! -d $DB_PATH ]; then
    mkdir -p $DB_PATH
    cp $SHELL_FOLDER/sacloud.db $DB_PATH
fi

###
### 3. clean old service
###
#systemctl disable bmssm.service

###
### 4. Copy ssm server binary
###
cp $SHELL_FOLDER/bmssm /bin

###
### 5. Copy service config file 
###
cp $SHELL_FOLDER/bmssm.service /etc/systemd/system/
